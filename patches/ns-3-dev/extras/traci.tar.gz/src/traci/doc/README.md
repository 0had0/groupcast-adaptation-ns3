### Description
This ns3 module implements a bidirectional coupling to the road traffic
simulator [SUMO](https://software.dlr.de/p/sumo/home/). It dynamically
synchronizes the positions of SUMO vehicles with corresponding ns3 nodes.
Additionally, the state of SUMO vehicles can be controlled via ns3, e.g.
for changing the speed. The module is built up on the
[TraCI API](http://sumo.dlr.de/wiki) of the SUMO simulator. The module was
originally published by TU Dresden / Vodafone Chair and later extended in the
ms-van3t / VaN3Twin projects; the sources here are a minimal mobility-only
subset taken from
[VaN3Twin `src/traci`](https://github.com/DriveX-devs/VaN3Twin/tree/master/src/traci).

### Usage in this repository
The module is registered automatically because it lives under `src/traci/`.
A companion module `src/vehicle-visualizer/` provides the optional web
visualizer (`vehicleVisualizer`).

To use SUMO mobility from any scratch/example target:
```cpp
#include "ns3/traci-client.h"
// ...
Ptr<TraciClient> sumo = CreateObject<TraciClient>();
sumo->SetAttribute("SumoConfigPath",  StringValue(cfg));
sumo->SetAttribute("SumoBinaryPath",  StringValue("sumo"));
sumo->SetAttribute("StartTime",       TimeValue(Seconds(0.0)));
sumo->SetAttribute("SynchInterval",   TimeValue(Seconds(0.1)));
sumo->SumoSetup(includeFn, excludeFn);
```

Then rebuild:
```sh
cd <ns3-root>
./ns3 configure --enable-examples --enable-tests
./ns3 build
```

### Remarks
ns3 does not support dynamic node generation/destruction — all nodes must
be defined BEFORE the simulation starts. For SUMO scenarios that include
and exclude vehicles during the simulation, you must define a "node pool"
before simulation starts and supply include/exclude callbacks to
`SumoSetup` so the TraCI client can recycle nodes from that pool.

### Updating SUMO source code of the module
The module embeds a subset of SUMO's own TraCI client (version 1.1.0),
with filenames renamed to avoid clashes with a system-installed SUMO.
To refresh these vendored sources from an upstream SUMO checkout:

```sh
cp <sumo-root>/src/config.h                    <ns3-root>/src/traci/model/sumo-config.h
cp <sumo-root>/src/foreign/tcpip/socket.h      <ns3-root>/src/traci/model/sumo-socket.h
cp <sumo-root>/src/foreign/tcpip/socket.cpp    <ns3-root>/src/traci/model/sumo-socket.cc
cp <sumo-root>/src/foreign/tcpip/storage.h     <ns3-root>/src/traci/model/sumo-storage.h
cp <sumo-root>/src/foreign/tcpip/storage.cpp   <ns3-root>/src/traci/model/sumo-storage.cc
cp <sumo-root>/src/utils/traci/TraCIAPI.h      <ns3-root>/src/traci/model/sumo-TraCIAPI.h
cp <sumo-root>/src/utils/traci/TraCIAPI.cpp    <ns3-root>/src/traci/model/sumo-TraCIAPI.cc
cp <sumo-root>/src/traci-server/TraCIConstants.h <ns3-root>/src/traci/model/sumo-TraCIConstants.h
cp <sumo-root>/src/libsumo/TraCIDefs.h         <ns3-root>/src/traci/model/sumo-TraCIDefs.h
```

After copying, adapt the corresponding `#include` lines to the renamed
headers:

* sumo-socket.h:  `#include "storage.h"`                    → `#include "sumo-storage.h"`
* sumo-socket.cc: `#include "socket.h"`                     → `#include "sumo-socket.h"`
* sumo-storage.cc: `#include "storage.h"`                   → `#include "sumo-storage.h"`
* sumo-TraCIAPI.h:
    * `#include <config.h>`                                 → `#include "sumo-config.h"`
    * `#include <foreign/tcpip/socket.h>`                   → `#include "sumo-socket.h"`
    * `#include <traci-server/TraCIConstants.h>`            → `#include "sumo-TraCIConstants.h"`
    * `#include <libsumo/TraCIDefs.h>`                      → `#include "sumo-TraCIDefs.h"`
* sumo-TraCIAPI.cc:
    * `#include <config.h>`                                 → `#include "sumo-config.h"`
    * `#include "TraCIAPI.h"`                               → `#include "sumo-TraCIAPI.h"`

### Authors (upstream)
Patrick Schmager, TU Dresden, Vodafone Chair, <patrick.schmager@tu-dresden.de>
Sebastian Kühlmorgen, TU Dresden, Vodafone Chair, <sebastian.kuehlmorgen@tu-dresden.de>

### References
[1] Y. Pigné, G. Danoy & P. Bouvry, "A platform for realistic online
vehicular network management," 2010 IEEE Globecom Workshops, Miami, FL,
2010, pp. 595-599.

[2] Wegener, Axel & Piorkowski, Michal & Raya, Maxim & Hellbrück, Horst &
Fischer, Stefan & Hubaux, Jean-Pierre. "TraCI: An Interface for Coupling
Road Traffic and Network Simulators." Proceedings of the 11th
Communications and Networking Simulation Symposium, CNS'08, 2008.
